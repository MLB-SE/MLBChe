import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(53.172047518706705,73.88276247261464,82.8809407135534); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(8.59718510773746,36.49930655806264,97.33911578770218); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(92.38854548846373,-33.03290981778643,11.418359154982511); ;
  }
}
