import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,71.78004913794304,-100.0,0,60.64342421185828); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-1.5413768704424484,-80.54570637973481,-16.86246257903217,0,-25.92780306622646); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(36.4031584082077,-2.118062632859406,-65.32928019974491,-90.24925278451212,0.31620246992171985); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(54.03519448285605,-45.98836356828511,-84.35183182338777,-26.13468853204745,-59.938343905014804); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(55.210516368276615,48.48933594482148,21.603596901084018,0,0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-56.81834222841835,70.51009127485068,94.65475873845762,65.65441704159994,-60.21172798220036); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-66.50268518536481,30.929251854606775,99.75098948880964,0,0); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-73.31447867449808,78.1434065102155,-5.182966470884878,59.90786436268721,47.48655785251867); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(77.94146584128202,49.503729459557654,-24.859487058032432,0,0); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(91.8274226830292,-100.0,18.93603456556284,4.959164729761995,73.33387585885703); ;
  }
}
