import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.26160731010513416,-47.3407538573255,5.722254688374534,-90.36562838090036); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.5599361308586026,-78.47576039197895,-36.943376015157895,-0.24138759508862506); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9097311589222128,-52.44433136468498,78.32291575738402,13.29424649152592); ;
  }
}
