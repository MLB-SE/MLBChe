import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(1.057019731179894,14.057019731179894); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(10.793279610500377,18.296144854516257); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(1.4064955553103573,48.59350444468964); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(14.29170764822642,15.107603876671716); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(15.834123729131292,32.54608561279392); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(1.7893166839845803E-7,3.5795956060336726E-4); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(18.91749659130444,19.732451246162487); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(-20.683522154865727,39.7817745120758); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(23.292007194134754,33.07591160332328); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(32.84693285801285,38.43710581475338); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(4.648038600058371E-12,2.1559305702651977E-6); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(53.2598279170316,71.20656017814085); ;
  }
}
