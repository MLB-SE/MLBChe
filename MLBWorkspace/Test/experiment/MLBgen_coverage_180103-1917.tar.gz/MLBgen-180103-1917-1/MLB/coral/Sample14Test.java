import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.5163423654165626,-52.17396094842353,-53.796788149349936,71.50726921745795); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.5984914963628825,-100.0,-53.0993130199519,77.68061550976594); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.8620811856535369,-88.99180105709213,166.15216649431693,7.966475356203361); ;
  }
}
