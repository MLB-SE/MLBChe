import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-20.663740900832806); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-5.0582459882031685); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.5106780880993256,2.13672815104706,-83.65205142069188,86.2994577327307); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(30.70899540196035,73.54475895268703,-77.68527630668902,50.55988598056919); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(31.082405926666127,-23.863309812430018,-20.803218718740908,33.20280909250911); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(34.431939240481,1.78622210546105,67.25359104804653,23.50061935794598); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(36.740632687088976,16.415632451229186,58.43511657863809,76.61874047787342); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(-43.13809768486527,98.32803382641234,55.047806011073476,-84.03667378253583); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(47.96471358760306,36.76297315529956,-9.48134730896875,63.57746953962513); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(49.47952263661132,-3.339815256006105,100.0,-14.815047792727633); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(50.045732841796536,-2.3921666040693736,28.751028703147966,-60.28022593256719); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(-51.797749812947316,95.64716647666827,-10.917563691553283,-98.76794028308666); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(52.67415602942593,-2.845582353513649,48.28087597037302,21.878849875114753); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(62.555051744465175,19.473211746705424,100.0,-1.5828949523508804); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(63.73345011717922,28.074035445534093,27.278440452194744,64.52904511051857); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(64.33906544667468,0.0,-12.155440894686059,-23.260596137524217); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(64.72455284464175,-57.89853364919888,-18.613456898726625,89.72599867820483); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(67.90240621289624,17.629162391782202,-86.19770402308704,27.687761704592845); ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(-73.68590957223829,67.84943953910141,-63.894965419515884,10.947535934691473); ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(91.35245907383174,4.304930945461294,41.14587578096834,90.472886899721); ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(-99.8906916223739,44.80321183866957,48.57675288534665,95.70650958968224); ;
  }
}
