import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-0.19974526460402808,-5.00637650650885E-4); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(3.700328344957704E-6,27.024628810647624); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(56.686384528873404,1.7640920448730446E-6); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(67.54613371692412,1.4804696360429044E-6); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-69.1766354574089,-88.08717145438602); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-91.23946601403514,41.20909101741418); ;
  }
}
