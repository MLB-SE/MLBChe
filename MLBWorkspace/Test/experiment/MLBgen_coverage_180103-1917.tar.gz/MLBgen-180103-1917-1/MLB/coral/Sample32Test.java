import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(11.615743878671609); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.000000000000004); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(89.93729631670831); ;
  }
}
