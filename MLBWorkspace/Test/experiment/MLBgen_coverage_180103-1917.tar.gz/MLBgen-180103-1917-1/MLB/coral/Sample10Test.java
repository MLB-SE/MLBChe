import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-27.646162104875543,70.9545317665818,34.79757929996737); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(40.259492612302466,1.0928255094718935,37.55482260563983); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-94.78499168750083,87.72242759559174,85.91521085994435); ;
  }
}
