import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(0.31942852309873254,1.174774862641956,-0.17357567328767232); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(15.103059158957691,97.30775362522493,86.83901023895018); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(16.355491007098607,-98.35318253023021,19.5156012963637); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(21.893765613236667,15.698180081915524,-81.45771238201186); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(28.716131004349336,-90.27880808815985,29.62298315722353); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(45.5371456565222,-34.681904755065744,-50.82261339983394); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(4.7187904541620185,-1.0839440027484102,90.1106287589831); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(55.105247229280366,15.818082261046134,-87.48710002168292); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(6.893477870024739,14.750720986401461,-91.40410400209147); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(72.83459674437904,-13.0291229784211,93.90277939314103); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(94.19513648746701,64.81801989318598,95.95111179230659); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(95.47533135209622,-19.67097031180387,98.77225733939946); ;
  }
}
