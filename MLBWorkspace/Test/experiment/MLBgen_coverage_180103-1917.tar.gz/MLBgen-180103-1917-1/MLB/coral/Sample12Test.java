import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.11241318878690265,0.8593425885113959,98.99483325712134,11.828523906118818); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.1602538041145749,0.6844330917215444,-29.19175212739873,30.546844905749253); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(0.5632517184622543,-0.715713983595549,-49.50519961597152,47.711845305704855); ;
  }
}
