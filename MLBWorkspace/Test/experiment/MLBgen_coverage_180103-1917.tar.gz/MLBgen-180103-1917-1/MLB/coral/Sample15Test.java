import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.6684573289997218,-86.16338650656593,84.02964771227624,8.832572472202287); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.8600190111815067,16.488579072961045,-40.18522517416861,88.67657643230555); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.9290200900616982,9.103700191235557,-54.511890825790424,-76.81459182850728); ;
  }
}
