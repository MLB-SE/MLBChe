import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(14.692953755964353,8.875252866494947,-78.03312420293676); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-40.81399898620697,-40.46946466760273,-79.84784581972764); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-43.0732593979948,-16.353753879596557,-3.5175475080856984); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(64.25281709094098,73.23279008670207,100.0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-67.87795947527691,-73.8531162582422,-1.6655581357679292); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(72.47567608072808,-47.57208943568896,-88.48568237882752); ;
  }
}
