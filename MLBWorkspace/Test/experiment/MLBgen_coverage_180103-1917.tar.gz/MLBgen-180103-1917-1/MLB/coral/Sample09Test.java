import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(22.351826824801492,76.71036795910778); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-57.44265277980673,11.144892197519031); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-85.33283406519259,-38.409755341194106); ;
  }
}
