import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(10.553423960062375,-88.92695428985408); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(24.608028436226576,53.70173902259364); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(27.653107705275172,51.21505260719862); ;
  }
}
