import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(68.8611557379549,-40.83604973997706); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-7.973012972075182,-15.812637289200879); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(85.03625347037853,54.60115044005016); ;
  }
}
