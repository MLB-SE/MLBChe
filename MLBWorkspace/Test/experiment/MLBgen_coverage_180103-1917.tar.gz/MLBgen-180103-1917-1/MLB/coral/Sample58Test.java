import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,3.7609955830176744,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(-0.695382915635697,-70.73888621809556,49.28223532980796,-29.47043531558593,-88.96983921186035); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,-78.66531474312677,0,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(14.254900467215023,66.0385209589325,-80.2915716714298,54.44391127369434,49.983488135576124); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(15.708309743878676,99.49565140602706,19.116208283769097,34.36474998589393,58.43023442036858); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(19.043593989201298,73.8134017287421,-92.0802312206777,28.673026358752566,83.42687717613407); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(20.187420135161787,22.25658028336016,-42.41075678133362,36.653052462526944,70.04471486865458); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(29.943519686742576,20.256512925295354,57.398140948917614,45.34275224524461,17.701856740166534); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(33.25973041434781,27.955598749595197,-61.58494061122675,4.633389910680986,82.3008190352846); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(42.44961807155357,-56.9902280140246,-86.76540805928852,59.22041567821648,43.121053991709175); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(4.292039960487642,28.743687091304935,-32.61254699228013,41.0745668986236,29.579833078567674); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(-78.03648901704003,-81.65673000291949,72.67437839518468,40.043356221566285,-98.37078497565581); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(8.597293074915768,12.889115965353312,92.6482873651778,-71.83149933226451,35.83200507961536); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(9.932069689572458,21.078070107038755,-31.73769678227794,-29.97620531986391,71.3625668857627); ;
  }
}
