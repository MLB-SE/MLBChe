import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-22.57232958509509,61.250649523544666); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(70.85025889664627,75.5626478776419); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(80.32717534433326,79.65817007751633); ;
  }
}
