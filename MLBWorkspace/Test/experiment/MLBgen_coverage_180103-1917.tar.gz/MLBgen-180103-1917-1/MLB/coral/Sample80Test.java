import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.02025692228128159,-73.04876116773549); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(21.70151025485012,45.23220588297562); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(59.782513380594,-52.153055313810356); ;
  }
}
