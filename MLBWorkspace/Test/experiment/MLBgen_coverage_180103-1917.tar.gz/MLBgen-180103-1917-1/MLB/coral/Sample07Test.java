import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-3.269606222466237,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,-42.18224984443987,0,-59.804885904736516); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-65.97344572471289,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,91.52603790151923,0,21.258766640262408); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(17.570414276545666,81.13732124713117,-84.38499371801393,47.41806171551678); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-42.794916411332906,-81.73290714451953,-45.841908133867435,15.445537723184685); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(4.883778942118241,-99.38525469863018,51.11389476540026,-51.73495943796051); ;
  }
}
