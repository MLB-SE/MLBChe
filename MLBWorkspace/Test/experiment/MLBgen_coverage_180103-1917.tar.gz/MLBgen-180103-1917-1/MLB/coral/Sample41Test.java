import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(1.8123610793700209,75.36696436480418); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(4.565124924769279,16.275240653980433); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(86.17760466158808,-0.9599339018365072); ;
  }
}
