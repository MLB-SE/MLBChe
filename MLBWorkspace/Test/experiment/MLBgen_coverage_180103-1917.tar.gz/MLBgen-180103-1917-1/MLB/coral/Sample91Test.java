import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-0.7622967377790815,-92.52066219856732); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(9.54015043500867,-97.07524536658983); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-97.74529212441429,3.4975125167204943); ;
  }
}
