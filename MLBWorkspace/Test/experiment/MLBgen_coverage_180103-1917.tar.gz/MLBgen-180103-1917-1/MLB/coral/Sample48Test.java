import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(24.547854998740746,-58.42600384333656,-7.221624707894918); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(27.364491333982556,11.38288617548318,-66.33523384929808); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-6.714796554433512,-50.54712690682967,-57.26192346126318); ;
  }
}
