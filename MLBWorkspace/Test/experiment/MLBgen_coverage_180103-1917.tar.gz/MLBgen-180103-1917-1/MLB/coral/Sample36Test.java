import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-22.1370951015233,-22.234437247674748,1.013367894412312); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-42.149620965073375,17.26753884166068,56.183910976608075); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(53.40701126463995,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-68.03184721562283,-53.90767494917501,8.70811479618937); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(77.84047201687605,0,0); ;
  }
}
