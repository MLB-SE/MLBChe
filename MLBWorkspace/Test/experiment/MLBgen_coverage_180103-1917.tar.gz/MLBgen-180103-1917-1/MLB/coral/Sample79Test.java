import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-11.203954384250167,-58.757816832904595,-79.25305954179389,51.3346760948281,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(1.1684203896374112E-6,100.0,-100.0,-100.0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-8.317872781735529E-6,-100.0,100.0,-100.0,0); ;
  }
}
