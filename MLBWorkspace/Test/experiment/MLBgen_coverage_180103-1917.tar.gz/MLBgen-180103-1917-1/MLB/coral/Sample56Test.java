import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-12.61842650226302,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,6.075960812523817E-4,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-3.9786382128696607,50.58711478668593,8.808565878233694,-54.43921166148493,43.44838881735137); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(47.80774083301179,-19.09636139379751,84.39727682557708,58.48880979229392,22.68358114929056); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(62.03015496330946,16.868911836452455,-67.89982110671909,40.692313449910614,53.68334841182363); ;
  }
}
