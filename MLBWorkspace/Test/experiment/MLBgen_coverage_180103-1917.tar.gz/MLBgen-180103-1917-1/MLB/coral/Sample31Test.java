import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.01320078221454235); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.10081102863883018); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-0.44455285933113453); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-0.6186319947231169); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-36.29469585015228); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(4.9842894092253065); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(67.07990172558729); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(88.0443746150707); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-92.4971379836244); ;
  }
}
