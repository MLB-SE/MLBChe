import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(69.9004365423729); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(75.58719008360384); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-99.14091793001782); ;
  }
}
