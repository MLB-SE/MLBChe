import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.38964180073033106,0.2587303986871454); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(100.0,-0.9536220670617397); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-84.46659950553101); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(22.642628248270327,38.001580925776494); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(41.85200446589786,92.56750871884532); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(42.68857205800359,0.6258655034175966); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(48.76068325159807,10.168173111989987); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(6.364857242948119,10.0); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(67.97746875243772,70.9541222523215); ;
  }
}
