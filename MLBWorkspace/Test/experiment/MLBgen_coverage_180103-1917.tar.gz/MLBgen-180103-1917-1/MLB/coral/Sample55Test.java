import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(32.667741143709236,-23.807126951302024,25.434059971789765); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(46.964222485735775,13.920387131316673,61.851558099776526); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(50.0154666007725,83.5053204946129,15.302838442852988); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(50.515994593136455,100.0,-78.80931923666614); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(5.482059091879587,-91.42156028417419,6.448830793736619); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(73.09616182720967,-23.313468795018238,-85.32013974778596); ;
  }
}
