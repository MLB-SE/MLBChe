import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(0.3391416432111072,0.3391416432111072); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(0.5541383184138198,0.5541383184138198); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(14.929498618894812,93.62248158673327); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(20.21209902323061,0.029747638210429805); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(44.5151185816037,69.38379627252377); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(61.66432524978856,48.54411136308465); ;
  }
}
