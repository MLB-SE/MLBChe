import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(100.0,100.0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(15.775779646565397,48.42900032913059); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(25.524491989072743,1.14795186569188); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(2.7795697442026883,7.726007962886998); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(3.8880845025123287,3.8880845025123287); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(5.932119370167527,62.557800884344324); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(61.904464559210936,71.73412350532973); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(68.14720829276939,76.88763668730442); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(69.5481545731476,3.717491278238299); ;
  }
}
