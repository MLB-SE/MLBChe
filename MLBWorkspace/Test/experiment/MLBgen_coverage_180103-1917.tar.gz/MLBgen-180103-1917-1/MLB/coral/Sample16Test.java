import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,13.091712092873365); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,53.77281345016803); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-51.45484660661799,15.318185073724152,-11.350570250782056,-70.4408390210893,-31.88951700720513); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(51.58843471634074,14.6943675240569,53.271239894991226,99.73891511620289,10.222565485750465); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-83.07846396985737,15.50892131607267,-17.68699919500153,-33.038304974424264,81.45957973305212); ;
  }
}
