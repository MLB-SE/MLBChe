import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(12.130658803932207,44.2855043940165); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(23.741092194388585,-16.543996408839106); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(43.3232391144307,60.75600937188078); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-64.6416705427591,31.73142543546038); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-7.83644804264236,68.21117182701951); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-78.48564431389386,0.27588157179391715); ;
  }
}
