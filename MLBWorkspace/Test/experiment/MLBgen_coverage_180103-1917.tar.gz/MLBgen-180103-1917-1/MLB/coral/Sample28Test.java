import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(0.4570037484539); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(7.389056098930649); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(74.82215166703608); ;
  }
}
