import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(15.707960922297609,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(39.26990815995939,-66.96862030639637); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-61.26105674725746,-18.643323004269984); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-91.59233867247283,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(96.00977635380164,-63.977112642760005); ;
  }
}
