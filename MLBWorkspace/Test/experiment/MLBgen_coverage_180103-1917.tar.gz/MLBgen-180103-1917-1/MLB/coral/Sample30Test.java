import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(10.555053111699195); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(169.86534909316748); ;
  }
}
