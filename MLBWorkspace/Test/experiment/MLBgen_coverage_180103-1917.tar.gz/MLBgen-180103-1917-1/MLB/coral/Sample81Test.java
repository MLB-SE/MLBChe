import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-14.425960048040182,63.25512622681518); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-27.854165649678905,5.58333329345146); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-70.08602354521364,-4.335862873024524); ;
  }
}
