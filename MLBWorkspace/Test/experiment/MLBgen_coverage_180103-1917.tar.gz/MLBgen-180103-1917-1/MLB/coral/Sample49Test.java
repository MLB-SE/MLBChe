import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.45765820428577797,70.83310568697553); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(0.47150469889775776,0.6866619975633993); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(1.5232250538351026,6.5723765032716726); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(34.2038121173255,47.33277027430128); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(4.605064183260495,28.432476616365022); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(48.93355413203318,87.97074465506606); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(55.11888181646336,35.19501631756154); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(6.654202145892074E-12,2.5795739020462758E-6); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(7.654718941398656,42.345281058601344); ;
  }
}
