import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(10.687999944960865,-13.49039933263549,-25.815948579586973); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-1.123827848648176,14.47414073365536,31.932114975302397); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-51.60295490938966,-75.23962081209167,13.952181757598638); ;
  }
}
