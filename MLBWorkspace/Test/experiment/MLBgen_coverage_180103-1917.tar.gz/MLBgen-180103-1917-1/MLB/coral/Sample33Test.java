import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-11.10290426547644); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(51.01037974505323); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-99.74556675147593); ;
  }
}
