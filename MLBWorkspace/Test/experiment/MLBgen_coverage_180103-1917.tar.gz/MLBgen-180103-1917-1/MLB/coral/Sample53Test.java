import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(17.512172089044583,32.778870336015586,9.467264071537798); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(23.459184369271853,59.988754276916154,-84.61087656773083); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(39.68116721984029,-3.560430118941966,21.935691193279155); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(45.958136749903446,0.5643117211187416,71.94086114083919); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(50.02562806951049,27.27718476252232,51.276085001916975); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(55.82695319082967,93.18266723527739,59.165586892203294); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(60.36840519561429,44.07767463366312,-61.65218326617823); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(85.66141352120724,-54.16507856140904,34.132187035298955); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(93.5460287228916,2.78632558873287,6.402135644513962); ;
  }
}
