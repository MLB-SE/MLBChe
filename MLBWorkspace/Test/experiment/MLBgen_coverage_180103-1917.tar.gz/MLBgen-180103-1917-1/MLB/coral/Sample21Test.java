import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-23.688285029494487,43.3393332571796); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-29.60268996354586,90.79014503262187); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(36.937458349046835,88.68165633918673); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-40.66580441778318,-45.96878370472632); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-85.42286659645792,85.35700394433198); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(96.09748566135022,39.6129550860189); ;
  }
}
