import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.8370152847309242); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,29.93358310686631); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.022465115556649026,-0.9564309928618165,0.06251679244921918,-0.06236891456073786); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-3.196039827986752,32.896785575244365,100.0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(16.86750508657691,8.881784197001252E-16,-32.85793858900584,4.328542922163997); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(2.490289042256629,-2.3532653108645523,3.844512153466525,48.23723269339527); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(2.495214824240904,51.85913233175151,81.9179767160935,34.21724074277296); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(27.117500923227105,-30.973442923702503,43.176871684153454,-11.080536181419617); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(27.729146889397782,45.36560719290833,-79.18615450997166,-42.12260651364019); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(39.4050559445769,-39.155652144939836,9.542665591894337,38.26190942471976); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(39.49048043696351,16.617310285747948,66.28997278597558,2.3764664532281756); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(39.664619633543424,34.101418475085666,-26.94848073624368,23.325998584293345); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(44.29678217347242,66.9109472939314,62.28213668012114,79.2589131100672); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(54.43914866624257,25.07838440813663,-27.702926503887284,61.71550100960221); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(56.51087336000458,78.84258379352286,20.924004895670407,-22.21683773738195); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(61.012477973494214,43.91226832162417,-2.387435651611881,-19.214796513234674); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(62.1464747746669,1.5571906437039615,75.57416154532243,30.820618428273093); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(65.64362597500121,-55.03509329928864,85.46183992973457,27.19514954041719); ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(71.44938322648818,72.20342718738502,95.34255946439441,48.310250949478785); ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(7.788846921973213,64.0221011527849,64.11608694638647,7.882832715574789); ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(83.84984947663668,60.21222171224176,87.47427356866274,93.12928153077522); ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(90.35335497255144,0.0,66.53333117582532,65.92032495718833); ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(-95.31895014438494,-71.60429284086104,-89.16362372118778,-20.47786922026573); ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(99.07291861283448,-58.673433368639195,84.93300860879523,-25.180229855110753); ;
  }
}
