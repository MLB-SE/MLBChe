import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(0.3820754229765839,99.02620529762606); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(7.612491823484376,50.33753993913211); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-87.98435164306242,4.108972502037204); ;
  }
}
