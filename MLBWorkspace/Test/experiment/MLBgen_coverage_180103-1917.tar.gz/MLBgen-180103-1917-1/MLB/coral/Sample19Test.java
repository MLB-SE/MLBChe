import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.7887059027180925,94.22240223275915,0.41332452261550623); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-0.8525153812209538,-2.257091338356034,-0.577002042280526); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.8903529019612648,68.50017103737306,0.6073233654066996); ;
  }
}
