import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-4.374787601904217,-23.063622282567394,-98.96107367836946); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-56.10420138477408,-98.38415879225974,73.4368123083892); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-78.69003651105999,-15.185158921544755,64.01325919797259); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-81.06696187938172,0,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-9.424830080501604,0,0); ;
  }
}
