import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(61.942561533860015,54.64140944418597,-56.01993094264299); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(81.66069007335835,45.73315541981978,-16.83540127636624); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(93.52555325037594,-56.02714229507681,49.734167230412964); ;
  }
}
