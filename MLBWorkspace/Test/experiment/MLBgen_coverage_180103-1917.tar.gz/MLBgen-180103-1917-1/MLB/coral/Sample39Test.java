import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(34.18738648431375,4.127659716822559E-18); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(43.547697202161714,84.7740271533522); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(49.937036743253515,-30.93341229679423); ;
  }
}
