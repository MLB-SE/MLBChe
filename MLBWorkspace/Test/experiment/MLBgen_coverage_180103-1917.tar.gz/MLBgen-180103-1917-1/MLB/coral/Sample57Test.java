import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,1.1827806858265717,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-51.07721416664883,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(17.386893241941923,47.77228537659367,14.746214510632711,78.72843984637177,-70.06085431477402); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(32.246394894329256,-69.33569875291889,-34.15633300019864,-81.94247405155309,-90.86947393342055); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(36.36111450506377,32.08389320421182,65.00148717239242,38.032160370045204,-13.386138809440823); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(5.909144684260113,20.934324269715134,-76.47352530316704,95.9896006466266,-10.020518212060963); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(6.828174125333291,-2.391383097665596,-5.89022393040203,82.45930317019503,48.03340572134161); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(75.2171096622111,57.29923944531018,-58.95571061058216,-5.372708887338689,53.43036908600999); ;
  }
}
