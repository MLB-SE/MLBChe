import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(2.052451380805269,4.23573386605792); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(2.4729554628710373,6.115609315599907); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-29.39578559379825,78.9256133129978); ;
  }
}
