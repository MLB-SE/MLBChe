import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,39.752320593532914,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,15.451269778775483,0,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,80.76304428620111,0,0,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,90.0,0,0,0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,34.42570476459699,-8.4879831639E-314,0,0,0); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-36.43975428231268,45.08074248687643,0,0,0); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,42.727373338645634,90.0,0,0,0); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-62.3287392642353,-81.98178291086506,0,0,0); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,8.553150637414404,-21.927536860547463,0,0,0); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,-100.0,0,0,0); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,-8.83345179993809,0,0,0); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(10.483795739159302,0,0,5.852095443365248E-98,50.83449868495824,0,0,0); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(-112.0,70.0,-470.0,112.0,12.0,0,0,435); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-16.92201875612217,0,0,91.14382817562671,-90.0,0,0,0); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(17.269636059170423,0,0,-62.60245459249521,-98.8854752077269,0,0,0); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(-308.0,-898.0,-178.0,-308.0,-544.0,0,0,-1); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(3.3503406487427445E-23,0,0,80.65714138019828,90.0,0,0,0); ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(39.343381568059726,0,0,46.479590189287904,-67.12100973324138,0,0,0); ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-468.0,845.0,-955.0,-468.0,893.0,0,0,0); ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(-59.177913721798994,0,0,0.5713463035516639,58.71112452250321,0,0,0); ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-60.35658052788164,-2.5698861333072927,33.164487623134846,-76.61713542023787,-91.19661494422688,0,0,0); ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(60.39499108770613,0,0,-83.30742348996938,-67.36135613019562,0,0,0); ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(65.76778957134104,0,0,-89.91962726369962,97.75901157844365,0,0,0); ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(77.38774518226,0,0,68.68361897263499,2.6961159259493475E-224,0,0,0); ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(78.85538445177363,0,0,20.64989885703723,25.38155794585731,0,0,0); ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(84.1029810955655,0,0,-69.62504769820532,-29.016623846940178,0,0,0); ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-874.0,115.0,-605.0,-874.0,-282.0,-502,0,0); ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(-96.69711528670707,0,0,-85.5665365562627,90.0,0,0,0); ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-9.745668307292521E-27,0,0,33.61240620772826,-90.0,0,0,0); ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(99.99999999999989,0,0,-51.52772813284045,8.463901093595641E-223,0,0,0); ;
  }
}
