import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-21.917095878329114,-39.69619824495463,65.42959584247988,78.00673503596227); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-23.9630160713411,-83.32473514035411,-79.62139467071374,37.12330299768411); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(32.389742342246905,-77.62821122839733,0,-38.94031256673233); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(64.18442120389216,54.30158737228663,0,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-70.9008929576909,-30.163782962873427,0,-72.406601652222); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(77.3521919358366,86.09724088562228,-41.52672857162898,-79.09201161186184); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(99.29137784307994,54.21800436777701,0,0); ;
  }
}
