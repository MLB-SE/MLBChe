import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.02353011380403977,0.003521180548284965); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.8858200456389227,41.136294041345536); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(10.789102243668097,39.072735396909195); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.3283299821828585,46.96979691636853); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(1.3737009060615075,35.217529233138556); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(3.150414598656326,25.810273084541095); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(33.562456311183894,52.191036151801086); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(6.6136506453152455,7.887600894800238); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(6.841871361996932E-13,8.271531222982166E-7); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(7.557941215302266,42.442058784697736); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(75.73523235101379,93.24856212136595); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(-88.10405761320683,52.88154457735362); ;
  }
}
