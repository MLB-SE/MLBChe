import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-10.446744018005916,98.82951578245036,82.46687019438312); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(29.85403199202824,-20.715592720855142,24.55256182095897); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-87.65511918739452,-1.402276434659251,-65.24827679555003); ;
  }
}
