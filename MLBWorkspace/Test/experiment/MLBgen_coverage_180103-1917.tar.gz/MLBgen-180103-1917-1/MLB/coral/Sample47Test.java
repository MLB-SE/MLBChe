import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-167.51095329112087,-396.3660401078139,-597.7993351776171); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-33.7940235557856,-81.02344590833152,-5.061253121617497); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(75.92743684499638,85.72700505618297,58.13847732012306); ;
  }
}
