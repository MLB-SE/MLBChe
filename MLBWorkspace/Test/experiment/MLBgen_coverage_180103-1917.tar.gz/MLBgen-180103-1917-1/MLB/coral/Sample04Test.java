import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-666.763851651549); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-83.8222980216282); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(93.7620802768985); ;
  }
}
