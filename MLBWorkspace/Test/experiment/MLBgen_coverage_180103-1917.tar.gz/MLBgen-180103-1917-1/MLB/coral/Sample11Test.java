import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.12716845065665439,-64.99155872155453,-32.022690843957264,1.4145081171573253); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.28048503018714754,-14.659161671652333,-3.8192928063831175,0.10450430336742045); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.7875901783471733,-89.64192334309598,84.32191107519239,-39.77193428904642); ;
  }
}
