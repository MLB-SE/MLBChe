import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(100.0,100.0,0,0,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,100.0,0,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(10.11797770100651,69.9149526509845,0,0,0,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-10.775177502858526,-61.487020883175084,-22.94175944992111,-9.365019714773025,-13.014756564253787,91.55457290399862,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-10.785480151092784,2.3798374334329786,4.026484545266712,-126.78726365224534,-64.5855464588327,4.705339048666961,0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-11.292565642985664,35.39085121538139,93.25372430587515,42.6463598738284,0,0,0); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(133.54715902149488,-80.55035936928965,-55.912602370998535,-41.471763776150915,59.15112733629252,74.72904727824209,-25.670044609021176); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-22.786214813068824,62.745646162107846,0,0,0,0,0); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-25.40937690603026,-50.7787314653106,-0.5137219509631734,-88.61317917326465,73.10931189627075,0,0); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(27.22690252390862,-85.17372254507637,-75.10664709865463,-56.80149729929875,36.545581643284976,-1.908580815548504,-26.97677222867108); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(50.331749467855246,-72.11481786302215,30.582118942579797,0,0,0,0); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-67.56767598111668,33.67266382898471,-0.0911345755651823,18.758421345973577,0,0,0); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(71.76882840673062,55.34936299383807,-64.15242397806114,98.83456643621295,-46.28004611371672,0,0); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-73.33744861158056,19.920603415314446,-37.303428998458735,66.56800118624818,35.52542320570399,-0.3221409652497158,0); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(82.84966792791404,62.116905065072025,30.508138276270802,67.83100353901237,-82.9654438332977,0,0); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-86.1614137787693,-67.1373136013494,-11.711964574660485,-15.173482593367396,41.57334239147997,168.1066444628721,-127.19855749865042); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-94.42586216672825,60.792364365972986,60.589440405777054,0,0,0,0); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(97.23316733282618,68.41778759293186,61.53862492484393,-52.56093899463392,0,0,0); ;
  }
}
