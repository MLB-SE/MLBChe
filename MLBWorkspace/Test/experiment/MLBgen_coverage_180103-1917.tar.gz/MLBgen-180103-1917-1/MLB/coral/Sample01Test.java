import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-17.669388331390063,-73.9028289484089); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(47.25355455938157,-43.21307511919736); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-80.22118738268908,39.22855253770214); ;
  }
}
