import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(26.224692386424977,27.429723230901317,-74.3953007486577); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(43.07827960900036,-13.022854350949103,16.831056473524825); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(55.66819133894211,24.77668616609219,86.8940398210747); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(58.668206553924506,85.4491943285104,64.32111031673344); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(64.57079919619727,41.87631719851993,64.25435223631638); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(68.59666965643052,96.93739594274464,-52.47218104849287); ;
  }
}
