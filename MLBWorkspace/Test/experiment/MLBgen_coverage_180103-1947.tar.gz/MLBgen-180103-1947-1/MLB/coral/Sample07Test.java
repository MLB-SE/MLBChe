import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,27.36936939111257,0,4.923814284821603); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,3.1415926508737537,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,38.126126467006195,0,35.12941004327205); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-97.08955263490265,0,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-34.342014175543184,-56.67354207639188,-59.634776776354094,-18.102526486443907); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(40.22437139267058,-67.8152898406056,33.39884235716545,40.53190170520409); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-75.37883877116657,73.017771547906,30.388442573895947,-49.13600421496998); ;
  }
}
