import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,38.411911087860034,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,16.53316686355511,0,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,51.42691366043991,0,0,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,90.0,0,0,0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-11.269238688746457,2.03E-322,0,0,0); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-29.021170043846325,-43.8234166116021,0,0,0); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-50.63993735553589,90.0,0,0,0); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-85.49844855210942,-30.396258308867388,0,0,0); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,98.89808146418355,22.893576387157722,0,0,0); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,38.79118462836083,1.63E-322,0,0,0); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(12.095953282639979,0,0,-62.003203135934726,90.0,0,0,0); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(-20.299896911899836,0,0,-76.1617328431644,-83.45754320518131,0,0,0); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(23.147785419036012,0,0,96.39975251889342,45.39406174224226,0,0,0); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-24.076938690350744,-94.55941836215398,85.44059205407763,24.076938660969688,-69.8048028458433,0,0,0); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(24.664220146707393,0,0,73.6267180574986,-15.944543914196956,0,0,0); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(-30.437894036715022,0,0,83.59280161273745,-47.00100908181626,0,0,0); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(35.41839433184481,-37.2130386757425,-70.32284135665768,89.05599614883474,89.33839652398322,0,0,0); ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(37.518171044732355,0,0,56.244970971774876,-90.0,0,0,0); ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-38.52784164423579,0,0,-49.489815300140314,24.21572661708214,0,0,0); ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(41.73864660736609,0,0,-61.7507676402234,87.36310080107529,0,0,0); ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(6.343673622230962E-26,0,0,100.0,-90.0,0,0,0); ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(7.7586712794218E-27,0,0,9.965614708397858,-90.0,0,0,0); ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(-9.404202461135057,0,0,1.6242827758820155E-114,-100.0,0,0,0); ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-98.6650814685284,0,0,63.52503716498272,1.7458768723248864E-251,0,0,0); ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(-98.91844557498287,83.67841245298754,-96.32168608929706,98.9184473972913,-100.0,0,0,0); ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-99.61459147991845,0,0,75.10102880954332,-88.010174343583,0,0,0); ;
  }
}
