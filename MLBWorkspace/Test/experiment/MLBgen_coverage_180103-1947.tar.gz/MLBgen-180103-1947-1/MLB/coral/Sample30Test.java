import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(122.80165477657009); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(84.22937636317741); ;
  }
}
