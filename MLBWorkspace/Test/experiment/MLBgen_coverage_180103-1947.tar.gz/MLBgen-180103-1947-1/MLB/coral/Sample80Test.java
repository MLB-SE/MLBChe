import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(10.073715208438514,75.06576536412834); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-1.454643747938615,2.031180316229083); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(30.762655394609283,-65.99909143566461); ;
  }
}
