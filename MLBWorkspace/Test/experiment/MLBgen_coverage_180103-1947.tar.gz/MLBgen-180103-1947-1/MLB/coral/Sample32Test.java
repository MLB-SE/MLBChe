import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(19.3928313486673); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(58.79591346968371); ;
  }
}
