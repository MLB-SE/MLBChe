import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.0658041692003053,0.05189731360341909); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-31.39054836643089); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(3.268396492570276,2.2379171824463953); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(43.01774197200314,0.9227071028756768); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(4.363133048272459,10.0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(5.214749381866454,64.64507676177269); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(53.203151582234284,71.33145424005548); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(6.982647696277439,11.69116530182015); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(96.28989478742602,61.38261511102138); ;
  }
}
