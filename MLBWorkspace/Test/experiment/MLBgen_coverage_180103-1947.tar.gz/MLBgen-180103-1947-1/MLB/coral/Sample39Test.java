import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.3919163233635032,-1.0317912809552056E-16); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(8.244793398563274,-73.57373793077697); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(92.84462767641702,79.02140898898841); ;
  }
}
