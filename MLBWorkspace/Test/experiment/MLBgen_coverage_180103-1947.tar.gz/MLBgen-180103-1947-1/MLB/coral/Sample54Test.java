import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(1.441546049666087,-14.146945353102794,62.30658262218199); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(15.504951924971392,-3.272258295175277,-24.418013499694894); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(31.129389467571656,-14.570976786771638,30.298384366728666); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(51.74873256014203,89.96022742209371,-87.56869793904502); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(59.039047568830824,-33.5537055501719,-56.59941893874938); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(66.19406431226489,34.296880668160554,-17.108435342834284); ;
  }
}
