import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(2.0916684635661182,2.0916684635661182); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(2.1343876550687355,3.6272324559904274); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(42.60267204385781,9.37498979853757); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(73.34445918895952,96.74714048802616); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(74.22404009427703,85.95865496509546); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(83.80310451099001,1.032702558688726); ;
  }
}
