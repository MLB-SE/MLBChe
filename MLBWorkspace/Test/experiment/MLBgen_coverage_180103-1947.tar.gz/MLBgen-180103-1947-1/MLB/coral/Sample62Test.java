import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,24.167198324760747); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-9.672844875939049); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.47036680913249995,99.27360528103137,68.08510767275338,97.75642366936736); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.5028573703694302,7.279991919491702,4.515363602059317,-2.261770947062955); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(100.0,0.0,-100.0,-100.0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-4.440892098500626E-16,11.03843035580499,-75.92288562363896); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(10.744422995091611,54.0894336043452,59.80003484120519,-12.543355849536027); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(15.13851995450051,0.6332920847457603,-56.17678761257914,2.149481715094595); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(22.08150045122248,-15.063588984009769,50.00712617850345,-42.989214711290735); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(2.262154262086479,1.7476340474524106,-0.6262451412867905,4.636033539645114); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(-27.404193201583098,-55.3518977273459,-74.36739737027037,40.15151916499883); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(29.875569106139153,77.44240857924223,56.673930415753546,92.2537426003926); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(30.741648709514976,59.86701851649349,62.39861475950141,54.29982008250386); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(34.46824489453317,9.760647122173552,44.06857136153246,92.22169793699763); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(37.39892960775674,-5.148997305965736,-57.59800728990878,92.71585205756637); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(39.56556210198684,63.16011401115546,88.70907714852726,-90.41470221977217); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(3.9813466612944155,-2.0880974297595278E-53,100.0,-79.395445509214); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(46.28883110988207,-26.390794298587522,64.74752114614623,-1.7539764277712369); ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(-51.57395942957328,53.82608481055186,56.38601360195565,25.03680038340275); ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(51.65503207317451,39.49074224697938,102.77045026550223,-5.5591381596831155); ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(56.83317900445215,-45.7457882971823,96.69149837737447,-60.89215027173678); ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(86.57895121243101,-63.619043084082975,60.4114799377291,81.36178295217022); ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(88.85624015290227,-68.64453838921767,89.3364885235485,81.90213395117141); ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(95.37782353547813,-65.96783510099871,100.0,-3.0950275182008102); ;
  }
}
