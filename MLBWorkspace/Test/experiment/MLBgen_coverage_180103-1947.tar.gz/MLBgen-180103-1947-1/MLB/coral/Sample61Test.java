import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,5.149808264985992); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,7.1308150432204656); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(-0.9245855095479362,1.8045275184636438,59.53349607112409,67.65615855126993); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(10.656560934149041,24.045499703104205,76.12709256654287,-4.028394544870338); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(13.438471744105357,39.97456004341632,-98.20181623537019,47.70617039512183); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(-14.522433510859159,-1.8473848408856952,82.2566671169784,4.55190974009308); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(17.811844920476958,71.25873727371791,96.79250558406375,76.79791507469136); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(2.9969368016692215,16.845933889594242,29.16311325292144,-27.41430601712709); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(34.19307087630966,-3.610395998215992,-57.93649552316658,-34.37502961565191); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(39.41129212997669,1.9843766088840198,-1.8699925262892947,4.7001438663525335); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(43.81655623582395,24.15700305311701,95.58728156940933,-20.793277205875896); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(-48.203805090059085,57.343815622738305,-44.54746756852275,-42.95338506008337); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(5.272420601253558,0.0,0.9109360612367468,8.248554403073134); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(59.5266501469595,36.39402315410563,47.35963566835926,48.56103763270587); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(6.6683240505668735,-2.0786419733356567,8.315605570382939,5.784741199191394); ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(71.78482365622762,17.285606223157046,94.18581654474329,76.3858829224753); ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(72.43080562945772,2.341696312035141,-37.77441954199898,-88.86031115749358); ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(78.51481549786877,31.5360068012711,-87.15691809891797,-37.33400905808735); ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(83.94580062271311,27.279209352228378,-34.87373886871923,-56.23591326552428); ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(94.6954595188447,54.29404529363114,-75.24299802583516,-16.624499153094845); ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(9.916252088103818,-4.754714324123491,65.10701382220586,-2.0855621204817245); ;
  }
}
