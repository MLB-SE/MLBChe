import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341003); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(50.19733943287545); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-63.72691056565007); ;
  }
}
