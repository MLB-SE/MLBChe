import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-27.897328048040006,-68.07436023352263); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-4.04729771158587,25.676691687286322); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-42.537840951033246,-74.67049638937517); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-61.815169142872215,41.71688366383569); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-72.63573610750589,-42.34139521173579); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-91.30695969238249,91.6565225538967); ;
  }
}
