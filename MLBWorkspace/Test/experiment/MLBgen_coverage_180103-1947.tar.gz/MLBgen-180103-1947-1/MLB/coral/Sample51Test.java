import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(1.1254709857961538,13.876728518655579); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.1539962819735792,44.26282735809636); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(17.87401771501301,32.12598228498699); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(20.976793074637072,21.413789419087934); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(26.105973400218517,50.11232504116839); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(2.996667042114154E-16,1.7310852038765318E-8); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(3.055407923195083E-11,5.527574443818396E-6); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(3.183388741241771,30.483953858787004); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(53.96010849207411,54.37005607580904); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(66.4174836577632,98.02560780877803); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(71.0863693627048,92.46741199974588); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(7.425811610171351,28.42379189669174); ;
  }
}
