import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(29.433228892557963,58.6526060366493,24.58993747406295); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-69.7597205387492,-14.973565204837797,-84.34732714127304); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(86.6462297250516,-9.345600337608118,77.30062938744348); ;
  }
}
