import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,2.754996836992234,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.07753838688263,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(17.31298426333116,-2.4991770347083673,-39.71101085357007,43.65140546464917,14.010072404024072); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-21.736846745989013,-90.7654915657184,-78.0738523690311,87.6871735947457,-18.89456689636046); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(95.37144992750603,-84.59754606584946,-38.26490198496171,67.07904260231342,14.59160833653867); ;
  }
}
