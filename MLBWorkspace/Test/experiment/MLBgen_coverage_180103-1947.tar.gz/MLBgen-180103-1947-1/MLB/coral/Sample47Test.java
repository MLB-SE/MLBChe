import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-433.3877103159653,-147.01929839751043,-576.3528529934496); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-78.16225353205766,-10.714592194674609,11.534179689259275); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(94.66423732087824,-91.19681682058267,-1.9115461153660789); ;
  }
}
