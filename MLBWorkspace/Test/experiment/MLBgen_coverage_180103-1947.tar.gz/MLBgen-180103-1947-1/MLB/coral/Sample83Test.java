import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-15.317445347992773,-2.297145521451796); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(4.259077779036574,18.139742169908594); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(8.27855057927556,68.53458114703238); ;
  }
}
