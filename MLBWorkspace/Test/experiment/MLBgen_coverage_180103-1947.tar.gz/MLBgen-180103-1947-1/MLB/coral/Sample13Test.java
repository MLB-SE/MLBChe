import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.10042653999617812,65.8961782536195,3.071721323878478,-25.974186049038167); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.8692589246794,-50.74926101188439,13.239994215696441,27.08751569394569); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9461194714352814,-74.29799902687236,47.01745290763037,-72.35023496392235); ;
  }
}
