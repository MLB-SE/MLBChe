import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.01599367685038544,0.5641928550097646,-2.5926498450396593,-82.17668237448174); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-0.05583100024955456,-0.9014920479511517,-10.31559182250949,52.344594160336584); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(0.16277922634782271,-0.11161886027772994,0.7981413813644697,-16.895991999381522); ;
  }
}
