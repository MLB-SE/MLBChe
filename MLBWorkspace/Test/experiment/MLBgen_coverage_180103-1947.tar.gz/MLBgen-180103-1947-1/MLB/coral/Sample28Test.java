import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(7.338129778785119); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(7.3890560989306495); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.605559499055346); ;
  }
}
