import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-25.542022416189425,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0000000000000036,-6.898025690396551,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(29.320178376789528,30.149999889004505,4.9410015343198666,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(38.8242825417676,0.9999999999999999,34.00004119867717,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(44.369299556301456,40.50017662731432,89.42698529862844,0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(56.445444003496625,1.000000000008214,74.39653296166973,0); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(64.52044922931336,0,63.30060962858312,0); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(-648.1566445614799,0,30.393657684456997,0); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(72.02590989341968,-97.74690491250446,2.929433514566256,0); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(-74.43389889712066,0,79.66205766769957,0); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(-88.7290842171701,0,0.5612718311462856,0); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(9.64387489391261,29.683269981518038,38.02181272993457,0); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(97.61203908892952,0,88.03907654112788,0); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(98.40924905777428,1.0,100.0,0); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(9.860761315262648E-32,60.8576620272044,1.0,0); ;
  }
}
