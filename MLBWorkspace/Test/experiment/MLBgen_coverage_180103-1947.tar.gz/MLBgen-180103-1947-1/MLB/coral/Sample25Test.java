import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(0.5175553743904828,30.620459239882358,100.0,39.17583576473004,-76.78087542426717); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(17.045715005751177,-45.25575496596579,50.76648865740924,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(19.926666353386608,86.34943028334007,8.997026731723864,0,-33.49090980610072); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(26.56800625948847,75.09693409479951,-98.68970092411926,-59.26208384590295,29.63788055926463); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-31.11983198581308,-86.64916195004515,96.24436563901531,55.6214318265408,66.62972504986729); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(42.7442991670471,-30.589285743073525,-35.00472180416301,0,0); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(4.600208777449172,-1.3872407068150268,99.06008240862536,46.54362088133692,-8.70718979865115); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-5.062606422057399,-42.2478771216739,-35.07262697266533,0,0); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(69.0869794319782,-65.77020117820265,-82.45920086855492,46.57315706517616,-64.87050973844077); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(99.27410503712244,-21.350612219123033,-85.57945334080969,0,-48.40496250876249); ;
  }
}
