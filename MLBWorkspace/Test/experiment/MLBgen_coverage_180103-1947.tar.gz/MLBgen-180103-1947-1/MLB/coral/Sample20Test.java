import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-19.389579205447504,9.235413484595286); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-30.756868500071523,-14.286562405005228); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-60.173875854096394,68.62194460831284); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-77.12523041792193,-63.53140513837601); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(78.02032516434124,56.65673618323146); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(88.78580267784503,-7.683471604040278); ;
  }
}
