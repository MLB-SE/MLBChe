import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(12.620373025839896,-26.717128981810617,-51.09178247802957); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-2.392447459323847,36.05774106067133,-22.00357022682695); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-32.99141074979924,21.497173061149056,4.945561964016392); ;
  }
}
