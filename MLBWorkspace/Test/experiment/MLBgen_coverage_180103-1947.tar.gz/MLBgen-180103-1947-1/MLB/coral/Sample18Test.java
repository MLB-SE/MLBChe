import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(-0.8483146124294052); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.9595496299847559); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(0.9632150280902749); ;
  }
}
