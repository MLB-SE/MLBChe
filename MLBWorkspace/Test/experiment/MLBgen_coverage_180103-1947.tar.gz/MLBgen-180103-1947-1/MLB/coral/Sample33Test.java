import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-12.067761883240678); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-17.494967297141486); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-49.480084294039244); ;
  }
}
