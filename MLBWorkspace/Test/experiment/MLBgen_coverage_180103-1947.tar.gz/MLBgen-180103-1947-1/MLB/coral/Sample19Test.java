import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.7548622806971821,-73.91371587893182,-0.4578911714007603); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.9188150511032995,20.313136230750484,-0.299740712612234); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9532588943359315,60.910961974169595,0.41930450373632766); ;
  }
}
