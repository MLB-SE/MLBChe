import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-2.588716731460579,9.290171047204524); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(2.9588671950251637,23.572248139960323); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(49.1982386699155,-28.01381007342019); ;
  }
}
