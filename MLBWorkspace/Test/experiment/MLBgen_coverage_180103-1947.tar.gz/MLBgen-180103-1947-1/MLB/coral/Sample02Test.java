import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(67.61483608062363,43.89969989467724); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(83.7266935211097,-8.47647161577396); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(96.96359680346734,5.138164438091137); ;
  }
}
