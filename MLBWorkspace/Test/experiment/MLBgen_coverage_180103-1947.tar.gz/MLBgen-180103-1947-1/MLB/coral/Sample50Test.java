import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.25222072231671255,0.46756730554338766); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.5513154663930113,46.95012354190666); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(0.8925473390765246,49.10745266092347); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(12.1439492474192,25.143949247419197); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(13.52726837811241,26.52726837811241); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(1.516333094436502,6.598506237461509); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(-16.643455728044998,14.140353653253058); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(4.853854054463064,45.14614594553694); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(61.06588657293216,82.56855143687426); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(72.07277708708278,73.45848736468946); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(8.829678575532589E-9,2.0180164512791827E-5); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(98.29650615263932,99.42541395054693); ;
  }
}
