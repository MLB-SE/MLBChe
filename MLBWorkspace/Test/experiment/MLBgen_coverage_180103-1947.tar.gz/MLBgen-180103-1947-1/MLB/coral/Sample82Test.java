import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-20.875721734961857,38.04205034231521); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-37.865507596463566,-2.6409259071794266E-6); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(4.2842913713715555E-4,0.23341082884375908); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-56.723575745421904,-34.73540118185099); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(71.28996593374674,1.4027219495789197E-6); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(8.74035366393855E-6,11.441184629929303); ;
  }
}
