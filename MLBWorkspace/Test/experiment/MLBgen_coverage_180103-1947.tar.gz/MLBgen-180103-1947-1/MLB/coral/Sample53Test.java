import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(100.0,0.05219017897558942,100.0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(15.46306466571218,2.7253381426400627,16.415424409954696); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(19.744393041517412,-85.78266731772324,16.7477518208685); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(28.219944904481395,-67.48876206146394,36.13140030527882); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(35.95335203818084,-50.4064350954613,54.86658067993153); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(5.028566098447669,67.97351488621516,-70.91421021530886); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(67.1033537618056,3.2220127121786675,100.0); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(97.7969321099352,-44.8972992481645,-70.8471318314798); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(99.768739316021,100.0,100.0); ;
  }
}
