import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.18525242316563598,0.4232744148981497); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(21.862597437529075,86.7632548268275); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(2.321847114316914E-5,4.911953818716E-9); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(39.388329212963185,67.88951304187063); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(5.578361476593074,42.257842340694936); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(-56.20826179997225,65.06945482598553); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(5.892383243128023,44.10761675687198); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(8.687928699052733,9.767093257351021); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(9.249033873790395,26.775190645304832); ;
  }
}
