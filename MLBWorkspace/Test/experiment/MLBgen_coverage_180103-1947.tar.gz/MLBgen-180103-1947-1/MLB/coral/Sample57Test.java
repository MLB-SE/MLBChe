import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,1.5391023491417428,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,67.66019026221193,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(14.590292207785467,43.82687855309268,89.55175825581574,32.11653350999322,-6.133758023915362); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(15.795812251899761,28.53979183971998,75.82791582693952,45.71315109609429,81.4508356102368); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(17.66850156036584,32.826881156331694,43.99641256761652,4.787998470149262,-37.54680235243906); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(-18.129447743166565,73.0094533666794,34.61777324390215,32.052185011378555,-35.76805470864477); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(-3.965950637180137,-5.711197873319236,24.984067879785194,-26.083066834084832,15.617919639329173); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(-71.79664574648118,0.09353163032174905,-22.282027960168648,-29.89461026306313,83.80529490703472); ;
  }
}
