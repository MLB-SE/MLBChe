import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0.4561246724372694,0,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,-23.29287475338748,0,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(12.71073090211089,0.7274991298905036,-12.662373716372318,73.2488971038209,-20.58710099977003); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(1.8107777430154783,33.61509665000264,-35.873466257605585,43.29505132355388,5.29012197281007); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(20.015122398221497,22.56253519599882,-42.86028963581423,56.548000738981784,76.12066124934158); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(22.413256204869867,28.493775190448616,-49.96531225342258,12.783020326966124,71.14553908572617); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-22.970655694479667,0.34939484390217507,56.03441434132368,-22.756808942043122,61.0494782770468); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(24.876158406044738,4.0830466669421375,-29.157728887174713,-2.571739183831469,60.8885017599444); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(27.45883141620351,84.9553782014604,96.58431116219069,-24.573318719022126,41.815763770091706); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(31.965693058779465,38.90269370783287,67.36214448697538,23.506769814730106,-33.885180174116385); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(40.03538334802781,4.178698137277365,-71.87600624584151,73.02819430994452,59.24345585069483); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(52.650536845563124,30.35813232886577,-82.2561312805848,76.41505339382667,12.02902312163424); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(63.62721364374738,-22.505811253787613,40.40135645187647,-2.134019148164157,88.83738112003732); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(94.42037889348055,43.61440646749776,22.194028958746344,52.82633841081429,30.63202589598268); ;
  }
}
