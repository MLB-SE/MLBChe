import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-32.43366499614379,-93.38789587841796,-71.22773412579029); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(55.35796434842381,-54.44452709777345,-34.840525205336846); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-79.735801200482,16.430818819850913,-71.46328689613483); ;
  }
}
