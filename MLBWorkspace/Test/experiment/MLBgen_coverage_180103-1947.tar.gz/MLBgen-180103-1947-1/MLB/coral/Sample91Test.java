import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-42.57234871778226,56.84001928852999); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(53.88941547393719,-27.495581236289922); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-73.95870744002747,54.846591357154054); ;
  }
}
