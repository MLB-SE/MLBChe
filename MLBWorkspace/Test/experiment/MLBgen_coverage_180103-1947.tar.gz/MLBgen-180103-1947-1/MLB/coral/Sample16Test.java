import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,1.050718052333906); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,21.172281093466054); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(84.83242131557552,15.191279325967088,66.48107066760753,-58.36827070421502,-35.29420708456156); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-85.05750915736157,14.93003868953095,-35.55641920043473,-93.53562341269136,-90.8670839431402); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-88.6644867439707,14.27738282354143,33.059615546875676,-22.883588842420792,-59.617207412734196); ;
  }
}
