import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-1.5623327775456188E-7,-100.0,-100.0,-100.0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(2.828036183349242E-7,100.0,100.0,100.0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(34.871275966422616,-68.18382150623003,-3.2808682166561454,-15.076083041256979,0); ;
  }
}
