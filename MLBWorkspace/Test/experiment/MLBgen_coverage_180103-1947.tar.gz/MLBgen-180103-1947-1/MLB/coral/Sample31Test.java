import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.3086245762697173); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(2.273247446751398); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(5.242281551167835); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-5.582379348821888); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(80.84343864260174); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-8.881784197001252E-16); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-96.25548174289962); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-96.30217904935472); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(97.57260647935311); ;
  }
}
