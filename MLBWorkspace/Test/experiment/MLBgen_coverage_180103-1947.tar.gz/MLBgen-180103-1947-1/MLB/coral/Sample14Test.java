import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.5411307652164936,46.66163336480442,25.320598574917923,27.678878683635787); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.5775023694647388,96.27045115464304,-100.0,19.87335900473981); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0.5908049458088982,27.091170347505482,-50.14597529034555,80.26954218289171); ;
  }
}
