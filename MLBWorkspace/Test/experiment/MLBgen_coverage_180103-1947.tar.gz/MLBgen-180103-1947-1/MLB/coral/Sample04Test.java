import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-53.10451051408087); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-661.1161594947608); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-6.996722951950744); ;
  }
}
