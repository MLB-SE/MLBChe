import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-60.90754160755325,-78.96650534024829); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-70.16657945343177,67.70732201835244); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(90.82152790796226,-42.696159869603946); ;
  }
}
