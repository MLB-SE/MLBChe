import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-3.00718147283969,89.99787821340982,-3.017440185983375); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-52.95063414877327,-25.050593816447517,63.31606820345678); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(56.75622735780374,36.95518671018368,42.9008520895662); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(72.76065804517614,-94.50174600403687,-49.23590018912136); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-81.56035710552598,47.02504089921629,15.834637854350504); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-98.6715213129409,47.8290476467426,-68.31572513545163); ;
  }
}
