import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-29.016011836089547,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-31.415907534984093,0,0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(34.528353194457,-70.20703165193916,-39.465834293720484); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-41.395049236341784,-79.09675346791501,-74.58608786510408); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-86.99839262056717,-16.42809188965397,51.71303998957024); ;
  }
}
