import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(23.894255243568168,-77.54361532317427); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-30.852345964532883,90.60331218717421); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(96.21145226590352,-31.628603530017372); ;
  }
}
