import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999982,1.9999999999999947); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.000000000000003); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(1.2398422494411818,0.2973665540581878); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(2.194731248427857,2.6221140043978437); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-38.496452916265824,-30.387530966782435); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(4.57072297428968,16.32078553340982); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-5.5587211439029005,36.45810189957607); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(5.751393791044194,27.327136748617512); ;
  }
}
