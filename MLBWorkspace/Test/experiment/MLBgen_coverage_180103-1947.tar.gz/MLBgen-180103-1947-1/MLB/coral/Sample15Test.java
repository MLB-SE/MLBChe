import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.17365683433074253,92.44400520187418,75.36869123946369,46.384257568650185); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.7398976345788526,-47.29424372501497,90.08455953834353,-2.7519965146163514); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.9590311426391054,-16.616315419851063,-64.7033525705094,46.23411078543484); ;
  }
}
