import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,-72.92366521019164,100.0,0,23.325216940410826); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-14.545671081511742,50.63377252072473,53.52963680747263,66.1382841328915,38.35678705421586); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-2.625087499484252,74.73503538636274,76.57648125300796,93.34588468811168,-15.587464727717418); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(53.21725910177503,32.82891679186744,14.716739892610505,0,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-62.511659746296864,17.442882131139104,33.69119400845368,-5.575501915181635,-18.694126388402548); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(68.97333043295973,-15.813782705356132,83.51293529693578,54.365793999687185,54.1824703614279); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(79.73963160742393,14.74790336301244,14.50878412564127,-23.83264709396724,70.08181550217225); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-82.2135936179097,-47.49749273501942,-68.17228422088384,0,99.92002800057267); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-83.5429728531317,-34.66292991553199,-32.21579164913119,0,0); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(94.98122820777576,42.161366311662164,-82.3325671058258,0,0); ;
  }
}
