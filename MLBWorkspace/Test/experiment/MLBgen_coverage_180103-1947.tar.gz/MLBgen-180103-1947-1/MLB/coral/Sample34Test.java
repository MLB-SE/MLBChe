import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-24.3473430653209); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(31.930481563463303); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-92.90047093628912); ;
  }
}
