import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.3842904332313566,-1.8389183329744299,-53.88540271553379,66.18253866072362); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.6447780807314429,63.3743518598002,37.66254706083247,70.34562627427826); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.8402909642730663,51.847489384735695,52.57986447673085,-85.23289241877316); ;
  }
}
