import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-24.48398521088241,5.449047874139735); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(55.285521467993306,88.90805027090812); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(5.996471997147097,2.799741418446927); ;
  }
}
