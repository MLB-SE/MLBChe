import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(116.60635166821389,74.87207737720195); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-43.66579749697055,6.4501608542616395); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(51.03876833739977,-85.67530156801466); ;
  }
}
