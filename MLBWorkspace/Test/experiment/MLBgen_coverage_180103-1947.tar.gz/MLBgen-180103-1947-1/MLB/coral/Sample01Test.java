import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(2.575614067895856,46.537842688651835); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(45.0303195653502,43.07874930650061); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(8.192358466761927,36.185051220843704); ;
  }
}
