import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(10.893828474463183,-61.611943449119465,6.879040483541716); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(13.892782632955331,0.5979942107384062,14.88657030162371); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(42.8494022282876,55.36689891139724,-25.377627687912636); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(50.000889365968476,-44.864198046329726,77.61442103262743); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(53.34533410991557,-3.353516533741299,18.36793189599757); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(96.7054413905536,12.766556902091224,54.6584611169863); ;
  }
}
