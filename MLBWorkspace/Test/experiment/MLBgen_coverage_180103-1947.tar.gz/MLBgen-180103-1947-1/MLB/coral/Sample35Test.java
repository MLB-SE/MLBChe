import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-36.815155166301096,-85.62135315082382); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(39.269908195370306,-42.13978673029834); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-49.435719444794415,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(62.831872419189665,0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(89.53539039442184,-92.03786931400548); ;
  }
}
