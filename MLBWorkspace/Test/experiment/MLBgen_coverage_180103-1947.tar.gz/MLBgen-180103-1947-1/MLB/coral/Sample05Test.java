import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-23.549054385428747,-64.76553496072663,-65.89006958759695); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(33.60367814444879,96.64362680602366,70.3851856715977); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-91.56994202297757,-57.84838138387558,-22.47902247233469); ;
  }
}
