import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(14.154071331817237,14.154071331817237); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(24.236706010722617,0.12546109606955724); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(3.3799591994557545,41.337896396257236); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(49.782526455870396,4.813135570140332); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(63.73145422900083,78.37301538329896); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(6.5500790907843935,42.90353609553091); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(77.32097997664638,98.2907086271459); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(8.573999403065898,43.56283278205632); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.826804960810492,1.3776053811741855); ;
  }
}
