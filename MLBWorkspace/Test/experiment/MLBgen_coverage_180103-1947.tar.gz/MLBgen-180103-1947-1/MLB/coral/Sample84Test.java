import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.776705796198911,0.6032718938489843,0,0); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999998,1.0,1.0); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000004,1.0,1.0); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-1.258992707844544,1.5850626384057374); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,2.9357878968998183,8.618850575583458); ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-5.450916993938102,29.712496074803195); ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-74.97720393647012,53.09097978132522); ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,8.219961080161374,88.07282757465354); ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0297379169167158,1.060360177535977,0,0); ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,-31.059538057700166,1.0,33.059538057700166); ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(-3.5157555145409276,12.360536838024984,0,0); ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(-77.18780175446594,75.94008183846123,0,0); ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(-9.999832301184394,99.99664605181079,0,0); ;
  }
}
