import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,-90.56382426424827,0,33.50093968365003); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(10.648039641262804,94.85256734552662,43.15419703833898,29.901368165692276); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(21.26433501528753,-58.85175332231529,63.32165486118819,66.41726287677966); ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-32.09513591666506,-64.52675111386519,55.52910760410225,-58.056297106456434); ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-3.306604705718968,48.172635694004896,0,-61.773453595692885); ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(55.670902569427426,-97.96989839264832,0,0); ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-99.90465438501643,92.36382802415625,0,0); ;
  }
}
