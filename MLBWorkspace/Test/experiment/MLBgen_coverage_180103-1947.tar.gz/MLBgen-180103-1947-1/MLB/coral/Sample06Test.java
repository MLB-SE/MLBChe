import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(20.700738406710784,48.71478578063483,87.09442557183121); ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(46.340169678796805,-29.700673712439038,-69.21705739478487); ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-91.441026746971,29.11324317766065,47.69294976277047); ;
  }
}
